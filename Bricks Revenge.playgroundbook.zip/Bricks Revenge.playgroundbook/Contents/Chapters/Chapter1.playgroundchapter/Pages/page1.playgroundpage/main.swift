//: # Welcome To My Playground!
//: Hello 😊, in this playground we are going to learn a little about some fundamentals so that you can start your own adventures in the world of **Game Development**.
/*:

 First of all, keep in mind that we'll be using the **Swift** language and the **SpriteKit** Framework. Let's see what technlogies we'll go through!
- SKShapeNode
- SKSpriteNode
- Physics Body Impulse
- Async Threads
- Touches

 **So, let's begin?**
*/
