//#-hidden-code
import PlaygroundSupport
import SwiftUI
import SpriteKit
import Game

public struct GameView1: View {

    @StateObject private var gameScene = GameScene1()

    public init() {}

    public var body: some View {
        SpriteView(scene: gameScene)
            .ignoresSafeArea()
    }
}

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = UIHostingController(rootView: GameView1())
//#-end-hidden-code
//: # First Step: Creating the ball
//:  **Let's get started!**
/*:

 On this page we are going to learn how to create a **SKShapeNode**, and how to apply an impulse to that node, so that will make it start moving around.

 Before continuing, remember that the Scene mentioned below is a **SKScene** of the SpriteKit Framework, which contains all of our nodes and logics, but we are not going to focus on that in this playground.
 */
// Creating a SKShapeNode with a custom size that will be our ball node.
let ball = SKShapeNode(circleOfRadius: 15)

// Here we can set some properties that we'll use to apply an impulse to the ball, you can try it with different values 😃
//#-code-completion(everything, hide)
var dx: CGFloat = /*#-editable-code*/25/*#-end-editable-code*/
var dy: CGFloat = /*#-editable-code*/-25/*#-end-editable-code*/

//#-hidden-code
class GameScene1: SKScene, ObservableObject, SKPhysicsContactDelegate {
    let ball = SKShapeNode(rectOf: CGSize(width: 50, height: 25), cornerRadius: 25)

    override func sceneDidLoad() {
        self.size = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        scene?.scaleMode = .fill
        backgroundColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)

        physicsBody = makeBorder()
        physicsWorld.gravity = CGVector(dx: 0, dy: 0)
        physicsWorld.contactDelegate = self

        makeBall()
    }

    func makeBorder() -> SKPhysicsBody {
        let border = SKPhysicsBody(edgeLoopFrom: frame)
        border.friction = 0
        return border
    }
//#-end-hidden-code
func makeBall() {
    // First we need to set the name, color and position of our ball.
    ball.name = "ball"
    ball.fillColor = /*#-editable-code color for the ball*/#colorLiteral(red: 0.9999960065, green: 1, blue: 1, alpha: 1)/*#-end-editable-code*/
    ball.lineWidth = 0
    ball.position = CGPoint(x: frame.midX, y: frame.midY)

    // After that we add a physics body to it, which will configure if it is affected by gravity, friction, restitution and rotation.
    makePhysicsBody(node: ball)

    // Always remember to add your nodes to your scene.
    addChild(ball)

    // By applying an impulse the ball will start moving around.
    ball.physicsBody!.applyImpulse(CGVector(dx: dx, dy: dy))
}
//#-hidden-code

    func makePhysicsBody(node: SKShapeNode) {
        node.physicsBody = SKPhysicsBody(rectangleOf: node.frame.size)
        node.physicsBody!.allowsRotation = false
        node.physicsBody!.friction = 0
        node.physicsBody!.restitution = 1
        node.physicsBody!.linearDamping = 0
        node.physicsBody!.contactTestBitMask = node.physicsBody!.collisionBitMask
    }
}
//#-end-hidden-code

