//#-hidden-code
import PlaygroundSupport
import SwiftUI
import SpriteKit
import Game

public struct GameView3: View {

    @StateObject private var gameScene = GameScene3()

    public init() {}

    public var body: some View {
        SpriteView(scene: gameScene)
            .ignoresSafeArea()
    }
}

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = UIHostingController(rootView: GameView3())
//#-end-hidden-code
//: # Third Step: Setting up the Slingshot Gesture
//:  **You're almost there!**
/*:

 Now, we are going to understand more about how to create our brick, how to remove it from the screen and we are also going to understand better some standard functions of SpriteKit, which is going to be used to recognize touches on the screen and move the brick.
 */
//#-hidden-code
class GameScene3: SKScene, ObservableObject, SKPhysicsContactDelegate {
    let ball = SKShapeNode(rectOf: CGSize(width: 50, height: 25), cornerRadius: 25)
    let brick = SKSpriteNode(color: SKColor(#colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)), size: CGSize(width: 130, height: 32))

    var startingPoint: CGPoint!
    var hasGone: Bool = false

    override func sceneDidLoad() {
        self.size = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        scene?.scaleMode = .fill
        backgroundColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)

        physicsBody = makeBorder()
        physicsWorld.gravity = CGVector(dx: 0, dy: 0)
        physicsWorld.contactDelegate = self

        makeBall()
        makeBrick()
    }

    func makeBorder() -> SKPhysicsBody {
        let border = SKPhysicsBody(edgeLoopFrom: frame)
        border.friction = 0
        return border
    }

    func makeBall() {
        ball.name = "ball"
        ball.fillColor = #colorLiteral(red: 0.9999960065, green: 1, blue: 1, alpha: 1)
        ball.lineWidth = 0
        ball.position = CGPoint(x: frame.midX, y: frame.midY+200)

        makePhysicsBody(node: ball)

        addChild(ball)
    }

    func makeBrick () {
        brick.name = "brick"
        brick.position = CGPoint(x: frame.midX, y: 120)
        startingPoint = brick.position

        makePhysicsBodyBrick(node: brick)

        addChild(brick)
    }

    func makePhysicsBodyBrick(node: SKSpriteNode) {
        node.physicsBody = SKPhysicsBody(rectangleOf: node.frame.size)
        node.physicsBody!.allowsRotation = false
        node.physicsBody!.friction = 0
        node.physicsBody!.restitution = 1
        node.physicsBody!.linearDamping = 0
        node.physicsBody!.contactTestBitMask = node.physicsBody!.collisionBitMask
    }

    func makePhysicsBody(node: SKShapeNode) {
        node.physicsBody = SKPhysicsBody(rectangleOf: node.frame.size)
        node.physicsBody!.allowsRotation = false
        node.physicsBody!.friction = 0
        node.physicsBody!.restitution = 1
        node.physicsBody!.linearDamping = 0
        node.physicsBody!.contactTestBitMask = node.physicsBody!.collisionBitMask
    }
//#-end-hidden-code
// First we are going to create a removeBrick function that will remove our brick after x seconds.
//#-code-completion(everything, hide)
func removeBrick() {
    DispatchQueue.main.asyncAfter(deadline: .now() + /*#-editable-code*/3/*#-end-editable-code*/) {
        self.brick.removeFromParent()
    }
}
// Now we'll configure three functions that are standard in a SKScene. First, the touchesBegan function.
override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
    // We need to check if our touch is touching our brick, and if the brick isn't gone.
    if checkIfTouchingBrick(hasGone: hasGone, touches: touches) {
        guard let touchLocation = touches.first?.location(in: self) else { return }
        // So if those conditions are true, we'll set our brick position to our touchLocation, so it'll look like a drag gesture.
        brick.position = touchLocation
    }
}
// In this function, we are going to update our brick position every time we change our touchLocation, and also stablish a limit to where we can drag around our brick.
override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
    if checkIfTouchingBrick(hasGone: hasGone, touches: touches) {
        guard let touchLocation = touches.first?.location(in: self) else { return }

        if shouldResetPosition() {
            brick.position = startingPoint
        } else {
            brick.position = touchLocation
        }
    }
}
// And finally we are going to set the impulse and remove our brick from the scene.
override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
    if checkIfTouchingBrick(hasGone: hasGone, touches: touches) {
        guard let touchLocation = touches.first?.location(in: self) else { return }
        // This function calculates the difference between our startPoint and our touchLocation, and apply this to an impulse, that'll launch our brick.
        calculateAndApplyImpulse(touchLocation: touchLocation)
        // Last of all, we set our hasGone to true, and remove our brick.
        hasGone = true
        removeBrick()
    }
}
//#-hidden-code

    func checkIfTouchingBrick(hasGone: Bool, touches: Set<UITouch>) -> Bool {
        if !hasGone {
            if let touch = touches.first {
                let touchLocation = touch.location(in: self)
                let touchedWhere = nodes(at: touchLocation)

                if !touchedWhere.isEmpty {
                    for node in touchedWhere {
                        if let sprite = node as? SKSpriteNode {
                            if sprite == brick {
                                return true
                            }
                        }
                    }
                }
            }
        }
        return false
    }

    func shouldResetPosition() -> Bool {
        if brick.position.x > startingPoint.x + 300 || brick.position.x < startingPoint.x - 300 || brick.position.y > startingPoint.y + 90 || brick.position.y < startingPoint.y - 90 {
            return true
        }
        return false
    }

    func calculateAndApplyImpulse(touchLocation: CGPoint) {
        let dx = -(touchLocation.x - startingPoint.x)
        let dy = -(touchLocation.y - startingPoint.y)
        let impulse = CGVector(dx: dx*0.8, dy: dy*0.8)
        brick.physicsBody!.applyImpulse(impulse)
        brick.physicsBody!.applyAngularImpulse(-0.01)
    }
}
//#-end-hidden-code



