//#-hidden-code
import PlaygroundSupport
import SwiftUI
import SpriteKit
import AVFoundation

public struct GameView4: View {

    @StateObject private var gameScene = GameScene4()

    public init() {}

    public var body: some View {
        ZStack {
            SpriteView(scene: gameScene)
                .ignoresSafeArea()

            VStack(alignment: .leading) {
                Text("Score: \(gameScene.score)")
                    .font((.system(size: 24, weight: .heavy, design: .rounded)))
                    .foregroundColor(.white)
                    .padding([.leading, .top])
                    .frame(maxWidth: .infinity, alignment: .leading)

                Spacer()
            }

            if gameScene.isGameOver {
                VStack {
                    Text("GAME OVER")
                        .font((.system(size: 42, weight: .heavy, design: .rounded)))
                        .foregroundColor(.white)

                    Text("Play Again")
                        .font((.system(size: 24, weight: .bold, design: .rounded)))
                        .foregroundColor(.white)
                        .padding()
                        .onTapGesture {
                            gameScene.restartGame()
                        }
                }
            }
        }
    }
}

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = UIHostingController(rootView: GameView4())
//#-end-hidden-code
//: # Last Step: Adding Game Logics
//:  **Congrats! You did it!**
/*:

 In this step we are going to learn about how to detect collisions, and how to assign an action to those collisions.
 Before getting started, I changed the logic of how the brick disappears, instead of disappearing after X seconds, it disappears after colliding with a node called ceiling, which is a red rectangle that you're going to see after you hit run, you are going to see that it's pretty easy to make a collision logic.

 P.S.: The HUD was made in **SwiftUI**, which is a pretty cool framework to make custom views, animations and much more.
 */
//#-hidden-code
class GameScene4: SKScene, ObservableObject, SKPhysicsContactDelegate {

    @Published var isGameOver = false
    @Published var score = 0
//#-end-hidden-code
// Here you can set how many bricks you have to try hit the ball.
//#-code-completion(everything, hide)
var numberOfBricks: Int = /*#-editable-code*/3/*#-end-editable-code*/
//#-hidden-code
    var initialNumberOfBricks: Int = 0

    let ball = SKShapeNode(rectOf: CGSize(width: 50, height: 25), cornerRadius: 25)
    let brick = SKSpriteNode(color: SKColor(#colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)), size: CGSize(width: 130, height: 32))

    var soundEffect: AVAudioPlayer?

    var startingPoint: CGPoint!
    var hasGone: Bool = false

    override func sceneDidLoad() {
        self.size = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        scene?.scaleMode = .fill
        backgroundColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)

        let path = Bundle.main.path(forResource: "sound.mp3", ofType:nil)!
        let url = URL(fileURLWithPath: path)

        do{
            soundEffect = try AVAudioPlayer(contentsOf: url)
        } catch {

        }

        initialNumberOfBricks = self.numberOfBricks

        physicsBody = makeBorder()
        physicsWorld.gravity = CGVector(dx: 0, dy: 0)
        physicsWorld.contactDelegate = self

        makeBall()
        makeBrick()
        makeFloor()
    }
//#-end-hidden-code

// This function is provided by the SKPhysicsContactDelegate, that detects every collision happened in the GameScene.
func didBegin(_ contact: SKPhysicsContact) {
    playSoundEffect()
    
// The first thing we need to do is to check if our nodes are the ball and the brick.
    if checkIfCollidedBallAndBrick(contact: contact) {
        // Then we can set our logics, so we remove both of them and update our score.
        removeBallAndBrick()
        updateScore(1)

        // Here we set our gameOver logic, so if we ran out of bricks we toggle our gameOver and remove our nodes, but if we didn't we just make new nodes.
        if numberOfBricks > 0 {
            makeBall()
            makeBrick()
        } else {
            isGameOver.toggle()
            removeBallAndBrick()
        }
    }
//#-hidden-code
    if contact.bodyA.node?.name == "brick" && contact.bodyB.node?.name == "floor" {
        removeBrick()

        if numberOfBricks > 0 {
            makeBrick()
        } else {
            isGameOver.toggle()
            removeBallAndBrick()
        }
    }
}

    func checkIfCollidedBallAndBrick(contact: SKPhysicsContact) -> Bool {
        if (contact.bodyA.node?.name == "ball" && contact.bodyB.node?.name == "brick") ||  (contact.bodyA.node?.name == "brick" && contact.bodyB.node?.name == "ball") {
            return true
        } else {
            return false
        }
    }

    func playSoundEffect() {
        DispatchQueue.main.async {
            self.soundEffect?.play()
        }
    }

    func removeBallAndBrick() {
        self.removeBall()
        self.removeBrick()
    }

    func restartGame() {
        self.isGameOver.toggle()
        self.numberOfBricks = self.initialNumberOfBricks
        self.makeBall()
        self.makeBrick()
        self.score = 0
    }

    func updateScore(_ newScore: Int) {
        score += newScore
    }

    func makeBorder() -> SKPhysicsBody {
        let border = SKPhysicsBody(edgeLoopFrom: frame)
        border.friction = 0
        return border
    }

    func makeBall() {
        ball.name = "ball"
        ball.fillColor = #colorLiteral(red: 0.9999960065, green: 1, blue: 1, alpha: 1)
        ball.lineWidth = 0
        ball.position = CGPoint(x: frame.midX, y: frame.midY)

        let size = CGSize(width: ball.frame.size.width*1.1, height: ball.frame.size.height*1.1)

        makePhysicsBody(node: ball)

        addChild(ball)

        let dx = Int.random(in: -50...50)
        let dy = Int.random(in: 20...50)
        ball.physicsBody!.applyImpulse(CGVector(dx: dx, dy: dy))
    }

    func makeBrick () {
        brick.name = "brick"
        brick.position = CGPoint(x: frame.midX, y: 120)
        startingPoint = brick.position
        self.hasGone = false

        makePhysicsBodyBrick(node: brick)

        addChild(brick)
    }

    func makeFloor() {
        let floor = SKSpriteNode(color: SKColor(.red), size: CGSize(width: UIScreen.main.bounds.width, height: 20))
        floor.name = "floor"
        floor.position = CGPoint(x: UIScreen.main.bounds.width / 2, y: UIScreen.main.bounds.height)

        floor.physicsBody = SKPhysicsBody(rectangleOf: floor.frame.size)
        floor.physicsBody!.allowsRotation = false
        floor.physicsBody!.isDynamic = false
        floor.physicsBody!.contactTestBitMask = floor.physicsBody!.collisionBitMask

        addChild(floor)
    }

    func makePhysicsBodyBrick(node: SKSpriteNode) {
        node.physicsBody = SKPhysicsBody(rectangleOf: node.frame.size)
        node.physicsBody!.allowsRotation = false
        node.physicsBody!.friction = 0
        node.physicsBody!.restitution = 1
        node.physicsBody!.linearDamping = 0
        node.physicsBody!.contactTestBitMask = node.physicsBody!.collisionBitMask
    }

    func makePhysicsBody(node: SKShapeNode) {
        node.physicsBody = SKPhysicsBody(rectangleOf: node.frame.size)
        node.physicsBody!.allowsRotation = false
        node.physicsBody!.friction = 0
        node.physicsBody!.restitution = 1
        node.physicsBody!.linearDamping = 0
        node.physicsBody!.contactTestBitMask = node.physicsBody!.collisionBitMask
    }

    func removeBrick() {
        self.brick.removeFromParent()
        self.numberOfBricks -= 1
    }

    func removeBall() {
        self.ball.removeFromParent()
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if checkIfTouchingBrick(hasGone: hasGone, touches: touches) {
            guard let touchLocation = touches.first?.location(in: self) else { return }
            brick.position = touchLocation
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if checkIfTouchingBrick(hasGone: hasGone, touches: touches) {
            guard let touchLocation = touches.first?.location(in: self) else { return }

            if shouldResetPosition() {
                brick.position = startingPoint
            } else {
                brick.position = touchLocation
            }
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if checkIfTouchingBrick(hasGone: hasGone, touches: touches) {
            guard let touchLocation = touches.first?.location(in: self) else { return }
            calculateAndApplyImpulse(touchLocation: touchLocation)

            hasGone = true
        }
    }

    func checkIfTouchingBrick(hasGone: Bool, touches: Set<UITouch>) -> Bool {
        if !hasGone {
            if let touch = touches.first {
                let touchLocation = touch.location(in: self)
                let touchedWhere = nodes(at: touchLocation)

                if !touchedWhere.isEmpty {
                    for node in touchedWhere {
                        if let sprite = node as? SKSpriteNode {
                            if sprite == brick {
                                return true
                            }
                        }
                    }
                }
            }
        }
        return false
    }

    func shouldResetPosition() -> Bool {
        if brick.position.x > startingPoint.x + 300 || brick.position.x < startingPoint.x - 300 || brick.position.y > startingPoint.y + 90 || brick.position.y < startingPoint.y - 90 {
            return true
        }
        return false
    }

    func calculateAndApplyImpulse(touchLocation: CGPoint) {
        let dx = -(touchLocation.x - startingPoint.x)
        let dy = -(touchLocation.y - startingPoint.y)
        let impulse = CGVector(dx: dx*0.8, dy: dy*0.8)
        brick.physicsBody!.applyImpulse(impulse)
        brick.physicsBody!.applyAngularImpulse(-0.01)
    }
}
//#-end-hidden-code
/*:

 **Now you're ready to make this your own game! Try adding best scores, power-ups, background music, levels, and all the things you would like to try! You can do this!**
 
 Thank you for playing my playground! 😊
 */



