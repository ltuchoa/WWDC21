//#-hidden-code
import PlaygroundSupport
import SwiftUI
import SpriteKit
import Game

public struct GameView2: View {

    @StateObject private var gameScene = GameScene2()

    public init() {}

    public var body: some View {
        SpriteView(scene: gameScene)
            .ignoresSafeArea()
    }
}

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = UIHostingController(rootView: GameView2())
//#-end-hidden-code
//: # Second Step: Creating the brick
//:  **Let's keep it going!**
/*:

 On this page we are going to learn how to create a **SKSpriteNode**, which is similar to the previous page, and  also create some variables that will be used on the next page.
 */
//#-hidden-code
class GameScene2: SKScene, ObservableObject, SKPhysicsContactDelegate {
    let ball = SKShapeNode(rectOf: CGSize(width: 50, height: 25), cornerRadius: 25)
//#-end-hidden-code
// First we need to initialize a SKSpriteNode with a custom color and size that will be our brick node. Try messing around with the color and size 😁
//#-code-completion(everything, hide)
let brick = SKSpriteNode(color: SKColor(/*#-editable-code*/#colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)/*#-end-editable-code*/), size: CGSize(width: /*#-editable-code*/130/*#-end-editable-code*/, height: /*#-editable-code*/32/*#-end-editable-code*/))

// We also need to create theses two variables that'll help us with our slingshot gesture.
var startingPoint: CGPoint!
var hasGone: Bool = false
//#-hidden-code
    override func sceneDidLoad() {
        self.size = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        scene?.scaleMode = .fill
        backgroundColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)

        physicsBody = makeBorder()
        physicsWorld.gravity = CGVector(dx: 0, dy: 0)
        physicsWorld.contactDelegate = self

        makeBall()
        makeBrick()
    }

    func makeBorder() -> SKPhysicsBody {
        let border = SKPhysicsBody(edgeLoopFrom: frame)
        border.friction = 0
        return border
    }

    func makeBall() {
        ball.name = "ball"
        ball.fillColor = #colorLiteral(red: 0.9999960065, green: 1, blue: 1, alpha: 1)
        ball.lineWidth = 0
        ball.position = CGPoint(x: frame.midX, y: frame.midY)

        makePhysicsBody(node: ball)

        addChild(ball)
    }
//#-end-hidden-code

// We're going to use a function similar to the one we used with the ball. The main difference is that we set our variable startingPoint to our brick initial position.
func makeBrick () {
    brick.name = "brick"
    brick.position = CGPoint(x: frame.midX, y: 120)
    startingPoint = brick.position

    makePhysicsBodyBrick(node: brick)

    addChild(brick)
}
//#-hidden-code

    func makePhysicsBodyBrick(node: SKSpriteNode) {
        node.physicsBody = SKPhysicsBody(rectangleOf: node.frame.size)
        node.physicsBody!.allowsRotation = false
        node.physicsBody!.friction = 0
        node.physicsBody!.restitution = 1
        node.physicsBody!.linearDamping = 0
        node.physicsBody!.contactTestBitMask = node.physicsBody!.collisionBitMask
    }

    func makePhysicsBody(node: SKShapeNode) {
        node.physicsBody = SKPhysicsBody(rectangleOf: node.frame.size)
        node.physicsBody!.allowsRotation = false
        node.physicsBody!.friction = 0
        node.physicsBody!.restitution = 1
        node.physicsBody!.linearDamping = 0
        node.physicsBody!.contactTestBitMask = node.physicsBody!.collisionBitMask
    }
}
//#-end-hidden-code


